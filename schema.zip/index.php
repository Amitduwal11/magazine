  
<?php  
	include $_SERVER['DOCUMENT_ROOT'].'config/init.php';
	redirect('cms/index');
	// debugger($_SERVER);
	// $user = new user();
	// $data = array(
	// 	'username' => 'Khwopa',
	// 	'session_token'=>tokenize()
	// );
	// $user->deleteUserByEmail('khwopa@magazine.com');
	//